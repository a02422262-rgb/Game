@echo off
rem Локальная сборка EXE (нужен установленный Node.js 20+)
call npm install
call npm run dist
echo.
echo Готово: файл Zarya-*.exe лежит в папке dist
pause
