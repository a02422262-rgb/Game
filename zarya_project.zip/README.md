# Заря — ЧВК СССР 1980
1. Создай репозиторий на GitHub и загрузи туда всё содержимое архива (с папкой .github).
2. Вкладка Actions → Build → Run workflow (или просто push в main).
3. Когда сборка зелёная — открой запуск и скачай из Artifacts: Zarya-exe, Zarya-apk, Zarya-ipa.
IPA без подписи: ставится через Sideloadly или AltStore (они подпишут твоим Apple ID).
Игра: www/index.html (можно открыть прямо в браузере).
