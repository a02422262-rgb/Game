# Заря — ЧВК СССР 1980
## Сборка EXE и APK на GitHub (ничего ставить не нужно)
1. Создай репозиторий на GitHub и загрузи всё содержимое архива (вместе с папкой .github).
2. Вкладка Actions -> Build EXE and APK -> Run workflow (или просто push в main).
3. Через 5-10 минут файлы Zarya-*.exe и Zarya.apk появятся в Releases (справа на странице репозитория) и в Artifacts запуска.
## IPA (по желанию)
Actions -> Build IPA (manual) -> Run workflow. IPA без подписи, ставится через Sideloadly или AltStore.
## Локально
build.bat собирает EXE (нужен Node.js). Игру можно открыть и без сборки: www/index.html.
